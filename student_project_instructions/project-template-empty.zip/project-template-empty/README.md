[WRITE YOUR EXPLANATIONS HERE IN MARKDOWN]


YOU CAN USE FOLLOWING TOOLS:

https://markdownlivepreview.com/
This website shows how your markdown code looks like when opened on GitHub

https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax
This tutorial outlines how to write with MARKDOWN

Further tutorials:
https://www.markdownguide.org/
https://www.markdowntutorial.com/